new ReverseArray();
new DogBreed({ breed: "hound" });
new Responsive();
new PostToApi();